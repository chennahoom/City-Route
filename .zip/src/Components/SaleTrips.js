import { useHistory } from 'react-router-dom';

function SaleTrips(props){
    console.log(props.filterTripsSearch);
    return(
        <div></div>
    )
}

export default SaleTrips; 