import { useState } from "react";

function TripForm(){
    const initForm = {trip_name_city: '', tour_date:'' , tour_time: '', tour_time: '', start_time:''};
    const [trip, setTrip] = useState(initForm);

    const handleInputChange = (event) =>{
        const {name, value} = event.target;
        setTrip({...trip,[name]:value });
    }

    const onSave = (event) =>{
        event.preventDefault();
        // props.addUser(user);
        // setUser(initForm);
        // history.push("/register");

    }

    return(
        //TODO: add map and add stops on map
        <form onSubmit={onSave}>
            <label>
                City:
                <select required name="trip_name_city" onChange={handleInputChange} >
                    <option value="">Choose</option>
                    <option value="Tel-Aviv">Tel-Aviv</option>
                    <option value="Berlin">Berlin</option>
                    <option value="London">London</option>
                    <option value="Amsterdam">Amsterdam</option>
                    <option value="Paris">Paris</option>
                </select><br/>
            </label>
            <label>
                Tour-Date:<input type="date" name="tour_date" onChange={handleInputChange}/><br/>
            </label>
            <label>
                Tour-Time:<input type="text" name="tour_time" onChange={handleInputChange}/><br/>
            </label>
            <label>
                Start-Time:<input type="text" name="start_time" onChange={handleInputChange}/><br/>
            </label>
            <button>Add Trip</button>
        </form>
    )
}

export default TripForm;
