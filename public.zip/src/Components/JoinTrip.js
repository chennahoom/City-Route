import { useHistory } from 'react-router-dom';


function JoinTrip(props) {
    
}

export default JoinTrip;
